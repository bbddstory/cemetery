# cemetery
To start the project in debug mode, use this command: DEBUG=cemetery:* npm start
