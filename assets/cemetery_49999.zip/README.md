# cemetery
To start the project in debug mode, use this command:

DEBUG=cemetery:* npm start

To start the node instance on the hosting service for production, use the following command:

nohup node bin/www &

To stop a currently running Node.js application, type the following command:

pkill node